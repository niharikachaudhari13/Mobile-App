const postModel = require("../models/postModel");
const { upload, cloudinary } = require("../config/cloudinary");

// create post
const createPostController = async (req, res) => {
  try {
    console.log('=== Create Post Request ===');
    console.log('Request body:', JSON.stringify(req.body, null, 2));
    console.log('Request file:', req.file ? {
      fieldname: req.file.fieldname,
      originalname: req.file.originalname,
      encoding: req.file.encoding,
      mimetype: req.file.mimetype,
      size: req.file.size,
      path: req.file.path
    } : 'No file uploaded');
    console.log('Auth user:', req.auth);

    // Extract fields from form data
    const title = req.body.title;
    const description = req.body.description;
    const mediaType = req.body.mediaType;
    
    //validate
    if (!title || !description) {
      console.log('Validation failed:', { title, description });
      return res.status(400).send({
        success: false,
        message: "Please Provide All Fields",
        received: {
          title: !!title,
          description: !!description
        }
      });
    }

    if (!req.auth || !req.auth._id) {
      return res.status(401).send({
        success: false,
        message: "User not authenticated",
      });
    }

    let mediaUrl = null;
    if (req.file) {
      try {
        console.log('Processing file upload...');
        mediaUrl = req.file.path;
        console.log('Media URL:', mediaUrl);
      } catch (uploadError) {
        console.error('Error processing file upload:', uploadError);
        return res.status(400).send({
          success: false,
          message: "Error processing file upload",
          error: uploadError.message
        });
      }
    }

    try {
      const post = await postModel({
        title,
        description,
        media: mediaUrl,
        mediaType,
        postedBy: req.auth._id,
      }).save();

      console.log('Post created successfully:', post);

      res.status(201).send({
        success: true,
        message: "Post Created Successfully",
        post,
      });
    } catch (dbError) {
      console.error('Database error:', dbError);
      return res.status(500).send({
        success: false,
        message: "Error saving post to database",
        error: dbError.message
      });
    }
  } catch (error) {
    console.error('Unexpected error in createPostController:', error);
    res.status(500).send({
      success: false,
      message: "Error in Create Post API",
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
};

// GET ALL POSTS
const getAllPostsContoller = async (req, res) => {
  try {
    const posts = await postModel
      .find()
      .populate("postedBy", "_id name")
      .sort({ createdAt: -1 });
    res.status(200).send({
      success: true,
      message: "All Posts Data",
      posts,
    });
  } catch (error) {
    console.error('Error in getAllPostsController:', error);
    res.status(500).send({
      success: false,
      message: "Error In GETALLPOSTS API",
      error: error.message
    });
  }
};

// get user posts
const getUserPostsController = async (req, res) => {
  try {
    const userPosts = await postModel.find({ postedBy: req.auth._id });
    res.status(200).send({
      success: true,
      message: "user posts",
      userPosts,
    });
  } catch (error) {
    console.error('Error in getUserPostsController:', error);
    return res.status(500).send({
      success: false,
      message: "Error in User POST API",
      error: error.message
    });
  }
};

// delete post
const deletePostController = async (req, res) => {
  try {
    const { id } = req.params;
    const post = await postModel.findById(id);
    
    if (post.media) {
      try {
        const publicId = post.media.split('/').pop().split('.')[0];
        await cloudinary.uploader.destroy(`social_media_posts/${publicId}`);
      } catch (cloudinaryError) {
        console.error('Error deleting from Cloudinary:', cloudinaryError);
      }
    }
    
    await postModel.findByIdAndDelete({ _id: id });
    res.status(200).send({
      success: true,
      message: "Your Post been deleted!",
    });
  } catch (error) {
    console.error('Error in deletePostController:', error);
    res.status(500).send({
      success: false,
      message: "error in delete post api",
      error: error.message
    });
  }
};

//UPDATE POST
const updatePostController = async (req, res) => {
  try {
    const { title, description } = req.body;
    const post = await postModel.findById({ _id: req.params.id });
    
    if (!post) {
      return res.status(404).send({
        success: false,
        message: "Post not found",
      });
    }

    if (!title || !description) {
      return res.status(400).send({
        success: false,
        message: "Please Provide post title or description",
      });
    }

    let mediaUrl = post.media;
    if (req.file) {
      try {
        if (post.media) {
          const publicId = post.media.split('/').pop().split('.')[0];
          await cloudinary.uploader.destroy(`social_media_posts/${publicId}`);
        }
        mediaUrl = req.file.path;
      } catch (uploadError) {
        console.error('Error updating media:', uploadError);
        return res.status(400).send({
          success: false,
          message: "Error updating media",
          error: uploadError.message
        });
      }
    }

    const updatedPost = await postModel.findByIdAndUpdate(
      { _id: req.params.id },
      {
        title: title || post?.title,
        description: description || post?.description,
        media: mediaUrl,
      },
      { new: true }
    );

    res.status(200).send({
      success: true,
      message: "Post Updated Successfully",
      updatedPost,
    });
  } catch (error) {
    console.error('Error in updatePostController:', error);
    res.status(500).send({
      success: false,
      message: "Error in update post api",
      error: error.message
    });
  }
};

module.exports = {
  createPostController,
  getAllPostsContoller,
  getUserPostsController,
  deletePostController,
  updatePostController,
  upload
};