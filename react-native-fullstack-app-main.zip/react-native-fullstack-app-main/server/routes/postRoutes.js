const express = require("express");
const { requireSignin } = require("../controllers/userController");
const {
  createPostController,
  getAllPostsContoller,
  getUserPostsController,
  deletePostController,
  updatePostController,
  upload
} = require("../controllers/postController");

//router object
const router = express.Router();

// CREATE POST || POST
router.post("/create-post", requireSignin, upload.single('media'), createPostController);

//GET ALL POSTs
router.get("/get-all-post", getAllPostsContoller);

//GET USER POSTs
router.get("/get-user-post", requireSignin, getUserPostsController);

//DELEET POST
router.delete("/delete-post/:id", requireSignin, deletePostController);

//UPDATE POST
router.put("/update-post/:id", requireSignin, updatePostController);

//export
module.exports = router;