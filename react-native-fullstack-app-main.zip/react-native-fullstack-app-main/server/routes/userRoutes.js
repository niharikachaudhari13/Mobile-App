const express = require("express");
const router = express.Router();
const { registerController, loginController, getUserProfile, requireSignin } = require("../controllers/userController");

// Register route
router.post("/register", registerController);

// Login route
router.post("/login", loginController);

// Get user profile (protected route)
router.get("/profile", requireSignin, getUserProfile);

module.exports = router;
