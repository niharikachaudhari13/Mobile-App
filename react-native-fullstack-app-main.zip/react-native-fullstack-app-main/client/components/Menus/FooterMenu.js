import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import React from "react";
import { useNavigation, useRoute } from "@react-navigation/native";
import { FontAwesome5 } from '@expo/vector-icons';

const FooterMenu = () => {
  // hooks
  const navigation = useNavigation();
  const route = useRoute();

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.tabItem}
        onPress={() => navigation.navigate("Home")}
      >
        <FontAwesome5
          name="home"
          style={[
            styles.iconStyle,
            route.name === "Home" && styles.activeIcon
          ]}
        />
        <Text style={[
          styles.labelText,
          route.name === "Home" && styles.activeText
        ]}>Home</Text>
      </TouchableOpacity>
      
      <TouchableOpacity 
        style={styles.tabItem}
        onPress={() => navigation.navigate("Myposts")}
      >
        <FontAwesome5
          name="list"
          style={[
            styles.iconStyle,
            route.name === "Myposts" && styles.activeIcon
          ]}
        />
        <Text style={[
          styles.labelText,
          route.name === "Myposts" && styles.activeText
        ]}>My Posts</Text>
      </TouchableOpacity>
      
      <TouchableOpacity 
        style={styles.tabItem}
        onPress={() => navigation.navigate("Post")}
      >
        <FontAwesome5
          name="plus-square"
          style={[
            styles.iconStyle,
            route.name === "Post" && styles.activeIcon
          ]}
        />
        <Text style={[
          styles.labelText,
          route.name === "Post" && styles.activeText
        ]}>Post</Text>
      </TouchableOpacity>
      
      <TouchableOpacity 
        style={styles.tabItem}
        onPress={() => navigation.navigate("Account")}
      >
        <FontAwesome5
          name="user"
          style={[
            styles.iconStyle,
            route.name === "Account" && styles.activeIcon
          ]}
        />
        <Text style={[
          styles.labelText,
          route.name === "Account" && styles.activeText
        ]}>Account</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: "white",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderTopWidth: 1,
    borderTopColor: "#f0f0f0",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 5,
  },
  tabItem: {
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 10,
  },
  iconStyle: {
    fontSize: 22,
    marginBottom: 4,
    color: "#8a8a8a",
  },
  activeIcon: {
    color: "#5CBFAF",
  },
  labelText: {
    fontSize: 12,
    color: "#8a8a8a",
  },
  activeText: {
    color: "#5CBFAF",
    fontWeight: "500",
  }
});

export default FooterMenu;