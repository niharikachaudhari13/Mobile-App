import { View, Text, StyleSheet, Alert, TouchableOpacity } from "react-native";
import React, { useState, useEffect } from "react";
import moment from "moment";
import axios from "axios";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import { useNavigation } from "@react-navigation/native";
import EditModal from "./EditModal";

const PostCard = ({ posts, myPostScreen, refreshPosts }) => {
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [post, setPost] = useState({});
  const navigation = useNavigation();

  // Debug posts data
  useEffect(() => {
    if (posts?.length > 0) {
      console.log("First post data:", posts[0]);
    }
  }, [posts]);

  // Handle delete prompt
  const handleDeletePrompt = (id) => {
    Alert.alert(
      "Delete Post",
      "Are you sure you want to delete this post?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => handleDeletePost(id),
        },
      ],
      { cancelable: true }
    );
  };

  // Delete post data
  const handleDeletePost = async (id) => {
    try {
      setLoading(true);
      const { data } = await axios.delete(`/post/delete-post/${id}`);
      setLoading(false);
      
      if (data?.success) {
        // Refresh posts after successful deletion
        if (refreshPosts) {
          refreshPosts();
        } else {
          navigation.push("Myposts");
        }
      } else {
        alert(data?.message || "Failed to delete post");
      }
    } catch (error) {
      setLoading(false);
      console.log("Delete error:", error);
      alert(error?.response?.data?.message || "Error deleting post");
    }
  };

  // Handle successful edit
  const handleEditSuccess = () => {
    setModalVisible(false);
    if (refreshPosts) {
      refreshPosts();
    } else {
      navigation.push("Myposts");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Total Posts: {posts?.length}</Text>
      
      {myPostScreen && (
        <EditModal
          modalVisible={modalVisible}
          setModalVisible={setModalVisible}
          post={post}
          onEditSuccess={handleEditSuccess}
        />
      )}
      
      {posts?.map((post, i) => (
        <View style={styles.card} key={post?._id || i}>
          {myPostScreen && (
            <View style={styles.actionButtons}>
              <TouchableOpacity
                style={styles.iconButton}
                onPress={() => {
                  setPost(post);
                  setModalVisible(true);
                }}
              >
                <FontAwesome5 name="pen" size={16} color="#5CBFAF" />
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.iconButton}
                onPress={() => handleDeletePrompt(post?._id)}
                disabled={loading}
              >
                <FontAwesome5 name="trash" size={16} color="#FF6B6B" />
              </TouchableOpacity>
            </View>
          )}
          
          <View style={styles.contentContainer}>
            <Text style={styles.title}>{post?.title}</Text>
            <View style={styles.divider} />
            <Text style={styles.description}>{post?.description}</Text>
          </View>
          
          <View style={styles.footer}>
            {post?.postedBy?.name ? (
              <View style={styles.footerItem}>
                <FontAwesome5 name="user" size={14} color="#5CBFAF" />
                <Text style={styles.footerText}>{post?.postedBy?.name}</Text>
              </View>
            ) : (
              <View style={styles.footerItem}>
                <FontAwesome5 name="user" size={14} color="#9E9E9E" />
                <Text style={styles.footerText}>Unknown User</Text>
              </View>
            )}
            
            <View style={styles.footerItem}>
              <FontAwesome5 name="clock" size={14} color="#5CBFAF" />
              <Text style={styles.footerText}>
                {post?.createdAt ? moment(post.createdAt).format("DD/MM/YYYY") : "Date unknown"}
              </Text>
            </View>
          </View>
        </View>
      ))}
      
      {posts?.length === 0 && (
        <View style={styles.emptyContainer}>
          <FontAwesome5 name="inbox" size={50} color="#BDBDBD" />
          <Text style={styles.emptyText}>No posts found</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#F5F5F5",
  },
  heading: {
    fontSize: 20,
    fontWeight: "600",
    color: "#212121",
    textAlign: "center",
    marginBottom: 20,
  },
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  actionButtons: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginBottom: 10,
  },
  iconButton: {
    padding: 8,
    marginLeft: 10,
  },
  contentContainer: {
    marginBottom: 10,
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: "#424242",
    marginBottom: 12,
  },
  divider: {
    height: 1,
    backgroundColor: "#E0E0E0",
    marginBottom: 12,
  },
  description: {
    fontSize: 16,
    color: "#616161",
    lineHeight: 22,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: "#E0F2F1",
  },
  footerItem: {
    flexDirection: "row",
    alignItems: "center",
  },
  footerText: {
    marginLeft: 6,
    fontSize: 14,
    color: "#757575",
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    padding: 50,
  },
  emptyText: {
    marginTop: 10,
    fontSize: 16,
    color: "#757575",
  },
});

export default PostCard;