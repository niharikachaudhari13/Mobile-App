import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import Home from "../screens/Home";
import Login from "../screens/auth/Login";
import Register from "../screens/auth/Register";
import Post from "../screens/Post";
import Account from "../screens/Account";
import Myposts from "../screens/Myposts";
import Recipes from "../screens/Recipes";
import RecipeDetails from "../screens/RecipeDetails";

const Stack = createNativeStackNavigator();

const MainStack = () => {
  return (
    <Stack.Navigator initialRouteName="Login">
      <Stack.Screen
        name="Login"
        component={Login}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Register"
        component={Register}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Home"
        component={Home}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Post"
        component={Post}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Account"
        component={Account}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Myposts"
        component={Myposts}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Recipes"
        component={Recipes}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="RecipeDetails"
        component={RecipeDetails}
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
};

export default MainStack; 