import { View, Text, StyleSheet, TextInput, Alert, TouchableOpacity, SafeAreaView, ScrollView } from "react-native";
import React, { useState, useContext } from "react";
import { AuthContext } from "../../context/authContext";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { Ionicons } from '@expo/vector-icons'; // Make sure to install expo vector icons

const Login = ({ navigation }) => {
  //global state
  const [state, setState] = useContext(AuthContext);
  
  // states
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  //function
  // btn funcn
  const handleSubmit = async () => {
    try {
      setLoading(true);
      if (!email || !password) {
        Alert.alert("Please Fill All Fields");
        setLoading(false);
        return;
      }
      setLoading(false);
      const { data } = await axios.post("/auth/login", { email, password });
      setState(data);
      await AsyncStorage.setItem("@auth", JSON.stringify(data));
      alert(data && data.message);
      navigation.navigate("Home");
      console.log("Login Data==> ", { email, password });
    } catch (error) {
      alert(error.response.data.message);
      setLoading(false);
      console.log(error);
    }
  };

  //temp function to check local storage data
  const getLocalStorageData = async () => {
    let data = await AsyncStorage.getItem("@auth");
    console.log("Local Storage ==> ", data);
  };

  getLocalStorageData();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.card}>
          {/* Back Button */}
          <View style={styles.backButtonContainer}>
            <TouchableOpacity style={styles.backButton}>
              <Ionicons name="chevron-back" size={24} color="#5CBFAF" />
            </TouchableOpacity>
          </View>
          
          {/* Register Link */}
          <View style={styles.registerLinkContainer}>
            <TouchableOpacity onPress={() => navigation.navigate("Register")}>
              <Text style={styles.registerLink}>Register</Text>
            </TouchableOpacity>
          </View>
          
          {/* Login Title */}
          <Text style={styles.pageTitle}>Login</Text>
          <Text style={styles.subtitle}>Welcome back, please login to your account.</Text>
          
          {/* Form Fields */}
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.inputBox}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoComplete="email"
              placeholderTextColor="#8a8a8a"
            />
            
            <TextInput
              style={styles.inputBox}
              placeholder="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={true}
              autoComplete="password"
              placeholderTextColor="#8a8a8a"
            />
          </View>
          
          {/* Forgot Password Link */}
          <TouchableOpacity style={styles.forgotPasswordContainer}>
            <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
          </TouchableOpacity>
          
          {/* Login Button */}
          <TouchableOpacity 
            style={styles.loginButton}
            onPress={handleSubmit}
            disabled={loading}
          >
            <Text style={styles.loginButtonText}>Login</Text>
          </TouchableOpacity>
          
          {/* Register Text */}
          <Text style={styles.registerTextLink}>
            Don't have an account?{' '}
            <Text 
              style={styles.registerLink}
              onPress={() => navigation.navigate("Register")}
            >
              Register
            </Text>
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  scrollContainer: {
    flexGrow: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  card: {
    backgroundColor: "white",
    borderRadius: 20,
    width: "100%",
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
    position: "relative",
  },
  backButtonContainer: {
    position: "absolute",
    top: 15,
    left: 15,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#e6f7f4",
    alignItems: "center",
    justifyContent: "center",
  },
  registerLinkContainer: {
    position: "absolute",
    top: 25,
    right: 25,
  },
  registerLink: {
    color: "#333",
    fontWeight: "500",
    fontSize: 14,
  },
  pageTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#000",
    marginTop: 40,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: "#8a8a8a",
    marginBottom: 25,
  },
  inputContainer: {
    width: "100%",
    marginBottom: 10,
  },
  inputBox: {
    backgroundColor: "#F1F5F4",
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
    fontSize: 14,
    width: "100%",
  },
  forgotPasswordContainer: {
    alignSelf: "flex-end",
    marginBottom: 20,
  },
  forgotPasswordText: {
    color: "#5CBFAF",
    fontSize: 12,
  },
  loginButton: {
    backgroundColor: "#5CBFAF",
    borderRadius: 8,
    padding: 15,
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
    marginBottom: 20,
  },
  loginButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
  registerTextLink: {
    fontSize: 12,
    color: "#8a8a8a",
    textAlign: "center",
  },
});

export default Login;