import { View, Text, StyleSheet, TextInput, Alert, TouchableOpacity, SafeAreaView, ScrollView } from "react-native";
import React, { useState } from "react";
import axios from "axios";
import { Ionicons } from '@expo/vector-icons'; // Make sure to install expo vector icons

const Register = ({ navigation }) => {
  // states
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  // btn funcn
  const handleSubmit = async () => {
    try {
      setLoading(true);
      if (!name || !email || !password) {
        Alert.alert("Please Fill All Fields");
        setLoading(false);
        return;
      }
      setLoading(false);
      const { data } = await axios.post("/auth/register", {
        name,
        email,
        password,
      });
      alert(data && data.message);
      navigation.navigate("Login");
      console.log("Register Data==> ", { name, email, password });
    } catch (error) {
      alert(error.response.data.message);
      setLoading(false);
      console.log(error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.card}>
          {/* Back Button */}
          <View style={styles.backButtonContainer}>
            <TouchableOpacity style={styles.backButton}>
              <Ionicons name="chevron-back" size={24} color="#5CBFAF" />
            </TouchableOpacity>
          </View>
          
          {/* Login Link */}
          <View style={styles.loginLinkContainer}>
            <TouchableOpacity onPress={() => navigation.navigate("Login")}>
              <Text style={styles.loginLink}>Login</Text>
            </TouchableOpacity>
          </View>
          
          {/* Register Title */}
          <Text style={styles.pageTitle}>Register</Text>
          <Text style={styles.subtitle}>Lorem ipsum dolor sit amet, consectetur.</Text>
          
          {/* Form Fields */}
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.inputBox}
              placeholder="Full Name"
              value={name}
              onChangeText={setName}
              placeholderTextColor="#8a8a8a"
            />
            
            <TextInput
              style={styles.inputBox}
              placeholder="Email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoComplete="email"
              placeholderTextColor="#8a8a8a"
            />
            
            <TextInput
              style={styles.inputBox}
              placeholder="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={true}
              autoComplete="password"
              placeholderTextColor="#8a8a8a"
            />
          </View>
          
          {/* Terms and Conditions */}
          <Text style={styles.termsText}>
            By registering you agree to our{'\n'}
            <Text style={styles.termsLink}>Terms and Conditions</Text>
          </Text>
          
          {/* Register Button */}
          <TouchableOpacity 
            style={styles.registerButton}
            onPress={handleSubmit}
            disabled={loading}
          >
            <Text style={styles.registerButtonText}>Register</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  scrollContainer: {
    flexGrow: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  card: {
    backgroundColor: "white",
    borderRadius: 20,
    width: "100%",
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
    position: "relative",
  },
  backButtonContainer: {
    position: "absolute",
    top: 15,
    left: 15,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#e6f7f4",
    alignItems: "center",
    justifyContent: "center",
  },
  loginLinkContainer: {
    position: "absolute",
    top: 25,
    right: 25,
  },
  loginLink: {
    color: "#333",
    fontWeight: "500",
    fontSize: 14,
  },
  pageTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#000",
    marginTop: 40,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: "#8a8a8a",
    marginBottom: 25,
  },
  inputContainer: {
    width: "100%",
    marginBottom: 20,
  },
  inputBox: {
    backgroundColor: "#F1F5F4",
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
    fontSize: 14,
    width: "100%",
  },
  termsText: {
    fontSize: 12,
    color: "#8a8a8a",
    textAlign: "center",
    marginBottom: 20,
    lineHeight: 18,
  },
  termsLink: {
    color: "#8a8a8a",
    textDecorationLine: "underline",
  },
  registerButton: {
    backgroundColor: "#5CBFAF",
    borderRadius: 8,
    padding: 15,
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
  registerButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
});

export default Register;