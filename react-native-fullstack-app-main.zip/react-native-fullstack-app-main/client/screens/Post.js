import {
  View,
  Text,
  StyleSheet,
  TextInput,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Image,
  Platform,
  Alert,
} from "react-native";
import React, { useState, useContext } from "react";
import { PostContext } from "../context/postContext";
import FooterMenu from "../components/Menus/FooterMenu";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";
import axios from "axios";

const Post = ({ navigation }) => {
  // global state
  const [posts, setPosts] = useContext(PostContext);
  
  // local state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [media, setMedia] = useState(null);
  const [mediaType, setMediaType] = useState(null); // 'image' or 'video'
  const [uploading, setUploading] = useState(false);

  // Request permissions (for older iOS versions)
  const requestPermissions = async () => {
    if (Platform.OS !== 'web') {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Sorry, we need camera roll permissions to make this work!');
        return false;
      }
      return true;
    }
    return true;
  };

  // Pick image from gallery
  const pickImage = async () => {
    const hasPermission = await requestPermissions();
    if (!hasPermission) return;

    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled) {
        setMedia(result.assets[0].uri);
        setMediaType('image');
      }
    } catch (error) {
      console.log('Error picking image:', error);
      Alert.alert('Error', 'Failed to pick image');
    }
  };

  // Pick video from gallery
  const pickVideo = async () => {
    const hasPermission = await requestPermissions();
    if (!hasPermission) return;

    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'video/*',
        copyToCacheDirectory: true,
      });

      if (result.type === 'success') {
        setMedia(result.uri);
        setMediaType('video');
        console.log('Video selected:', result);
      }
    } catch (error) {
      console.log('Error picking video:', error);
      Alert.alert('Error', 'Failed to pick video');
    }
  };

  // Remove selected media
  const removeMedia = () => {
    setMedia(null);
    setMediaType(null);
  };

  // Upload media to server
  const uploadMedia = async () => {
    if (!media) return null;

    try {
      setUploading(true);
      
      // Create form data
      const formData = new FormData();
      
      // Add file to form data
      const fileExtension = media.split('.').pop();
      const fileName = `${Date.now()}.${fileExtension}`;

      formData.append('file', {
        uri: media,
        name: fileName,
        type: mediaType === 'image' ? `image/${fileExtension}` : `video/${fileExtension}`
      });

      // Upload to server
      const { data } = await axios.post('/upload/media', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setUploading(false);
      
      return data.url; // Return the URL of uploaded media
    } catch (error) {
      setUploading(false);
      console.log('Error uploading media:', error);
      Alert.alert('Upload Failed', 'Failed to upload media file');
      return null;
    }
  };

  // Handle form data post DATA
  const handlePost = async () => {
    try {
      if (!title) {
        Alert.alert('Missing Field', 'Please add post title');
        return;
      }
      if (!description) {
        Alert.alert('Missing Field', 'Please add post description');
        return;
      }
      
      setLoading(true);
      
      // Create form data
      const formData = new FormData();
      
      // Add text fields as strings
      formData.append('title', title.toString());
      formData.append('description', description.toString());
      if (mediaType) {
        formData.append('mediaType', mediaType.toString());
      }
      
      // Add media if exists
      if (media) {
        const fileExtension = media.split('.').pop();
        const fileName = `${Date.now()}.${fileExtension}`;
        
        // For video files, we need to handle the URI differently
        const file = {
          uri: media,
          name: fileName,
          type: mediaType === 'image' 
            ? `image/${fileExtension}`
            : `video/${fileExtension}`,
        };

        console.log('Uploading file:', file);
        formData.append('media', file);
      }
      
      console.log('FormData contents:', {
        title,
        description,
        mediaType,
        hasMedia: !!media
      });
      
      const { data } = await axios.post("/post/create-post", formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Accept': 'application/json',
        },
        transformRequest: (data) => {
          return data;
        },
      });
      
      console.log('Post created successfully:', data);
      
      setLoading(false);
      setPosts([...posts, data?.post]);
      Alert.alert('Success', data?.message || 'Post created successfully');
      
      // Reset form
      setTitle("");
      setDescription("");
      setMedia(null);
      setMediaType(null);
      
      navigation.navigate("Home");
    } catch (error) {
      console.error('Error creating post:', error);
      setLoading(false);
      
      let errorMessage = 'An error occurred while creating the post';
      
      if (error.response) {
        console.error('Error response:', error.response.data);
        errorMessage = error.response.data.message || errorMessage;
      } else if (error.request) {
        console.error('Error request:', error.request);
        errorMessage = 'No response from server. Please check your internet connection.';
      } else {
        console.error('Error message:', error.message);
        errorMessage = error.message || errorMessage;
      }
      
      Alert.alert('Error', errorMessage);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.headerContainer}>
          <View style={styles.circle}>
            <FontAwesome5 name="edit" size={24} color="#FFFFFF" />
          </View>
          <Text style={styles.titleText}>Post Recipes</Text>
          <Text style={styles.subtitleText}>
            Share your recipes with the community
          </Text>
        </View>

        <View style={styles.formContainer}>
          <View style={styles.inputWrapper}>
            <Text style={styles.inputLabel}>Recipes Title</Text>
            <TextInput
              style={styles.input}
              placeholder="Add recipes title"
              placeholderTextColor="#90A4AE"
              value={title}
              onChangeText={(text) => setTitle(text)}
            />
          </View>

          <View style={styles.inputWrapper}>
            <Text style={styles.inputLabel}>Description</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Add recipes"
              placeholderTextColor="#90A4AE"
              multiline={true}
              numberOfLines={6}
              textAlignVertical="top"
              value={description}
              onChangeText={(text) => setDescription(text)}
            />
          </View>

          {/* Media Preview */}
          {media && (
            <View style={styles.mediaPreviewContainer}>
              <View style={styles.mediaPreview}>
                {mediaType === 'image' ? (
                  <Image source={{ uri: media }} style={styles.mediaPreviewImage} />
                ) : (
                  <View style={styles.videoPreview}>
                    <FontAwesome5 name="video" size={36} color="#4DB6AC" />
                    <Text style={styles.videoText}>Video Selected</Text>
                  </View>
                )}
                <TouchableOpacity 
                  style={styles.removeMediaButton} 
                  onPress={removeMedia}
                >
                  <FontAwesome5 name="times-circle" size={22} color="#F44336" />
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Media Upload Buttons */}
          <View style={styles.mediaButtonsContainer}>
            <TouchableOpacity 
              style={[styles.mediaButton, mediaType === 'image' && styles.activeMediaButton]} 
              onPress={pickImage}
              disabled={uploading || loading}
            >
              <FontAwesome5 name="image" size={16} color={mediaType === 'image' ? "#FFFFFF" : "#4DB6AC"} />
              <Text style={[styles.mediaButtonText, mediaType === 'image' && styles.activeMediaButtonText]}>
                Image
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[styles.mediaButton, mediaType === 'video' && styles.activeMediaButton]} 
              onPress={pickVideo}
              disabled={uploading || loading}
            >
              <FontAwesome5 name="video" size={16} color={mediaType === 'video' ? "#FFFFFF" : "#4DB6AC"} />
              <Text style={[styles.mediaButtonText, mediaType === 'video' && styles.activeMediaButtonText]}>
                Video
              </Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.postButton}
            onPress={handlePost}
            activeOpacity={0.8}
            disabled={loading || uploading}
          >
            <Text style={styles.postButtonText}>
              {loading || uploading ? "Uploading..." : "Create Post"}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={styles.footerContainer}>
        <FooterMenu />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  headerContainer: {
    alignItems: "center",
    marginTop: 40,
  },
  circle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#4DB6AC",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 15,
  },
  titleText: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#212121",
    marginBottom: 8,
  },
  subtitleText: {
    fontSize: 14,
    color: "#757575",
    marginBottom: 24,
  },
  formContainer: {
    paddingHorizontal: 25,
  },
  inputWrapper: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: "500",
    color: "#424242",
    marginBottom: 8,
    paddingLeft: 4,
  },
  input: {
    backgroundColor: "#E0F2F1",
    height: 50,
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    color: "#424242",
  },
  textArea: {
    height: 150,
    paddingTop: 12,
  },
  mediaPreviewContainer: {
    marginBottom: 20,
  },
  mediaPreview: {
    position: 'relative',
    width: '100%',
    height: 200,
    backgroundColor: "#E0F2F1",
    borderRadius: 8,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mediaPreviewImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  videoPreview: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  videoText: {
    marginTop: 8,
    color: "#424242",
    fontSize: 16,
  },
  removeMediaButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(255,255,255,0.8)',
    borderRadius: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mediaButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  mediaButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#E0F2F1',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#4DB6AC',
    width: '45%',
  },
  activeMediaButton: {
    backgroundColor: '#4DB6AC',
  },
  mediaButtonText: {
    color: '#4DB6AC',
    fontWeight: '500',
    marginLeft: 8,
  },
  activeMediaButtonText: {
    color: '#FFFFFF',
  },
  postButton: {
    backgroundColor: "#4DB6AC",
    height: 50,
    borderRadius: 8,
    marginTop: 10,
    marginBottom: 30,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  postButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
  footerContainer: {
    justifyContent: "flex-end",
  },
});

export default Post;