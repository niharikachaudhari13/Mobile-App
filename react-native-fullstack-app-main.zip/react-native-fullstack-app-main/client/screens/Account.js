import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
} from "react-native";
import React, { useContext, useState } from "react";
import { AuthContext } from "../context/authContext";
import FooterMenu from "../components/Menus/FooterMenu";
import axios from "axios";

const Account = () => {
  //global state
  const [state, setState] = useContext(AuthContext);
  const { user, token } = state;
  //local state
  const [name, setName] = useState(user?.name);
  const [password, setPassword] = useState(user?.password);
  const [email] = useState(user?.email);
  const [loading, setLoading] = useState(false);

  //handle update user data
  const handleUpdate = async () => {
    try {
      setLoading(true);
      const { data } = await axios.put("/auth/update-user", {
        name,
        password,
        email,
      });
      setLoading(false);
      let UD = JSON.stringify(data);
      setState({ ...state, user: UD?.updatedUser });
      alert(data && data.message);
    } catch (error) {
      alert(error.response.data.message);
      setLoading(false);
      console.log(error);
    }
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.headerContainer}>
          <View style={styles.imageContainer}>
            <Image
              source={{
                uri: "https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_1280.png",
              }}
              style={styles.profileImage}
            />
          </View>
          <Text style={styles.titleText}>My Profile</Text>
        </View>
        
        <View style={styles.formContainer}>
          <Text style={styles.warningText}>
            Currently you can only update your name and password*
          </Text>
          
          <View style={styles.inputWrapper}>
            <Text style={styles.inputLabel}>Name</Text>
            <TextInput
              style={styles.input}
              value={name}
              onChangeText={(text) => setName(text)}
              placeholder="Enter your name"
              placeholderTextColor="#90A4AE"
            />
          </View>
          
          <View style={styles.inputWrapper}>
            <Text style={styles.inputLabel}>Email</Text>
            <TextInput 
              style={[styles.input, styles.disabledInput]}
              value={email} 
              editable={false}
              placeholder="Your email"
              placeholderTextColor="#90A4AE"
            />
          </View>
          
          <View style={styles.inputWrapper}>
            <Text style={styles.inputLabel}>Password</Text>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={(text) => setPassword(text)}
              secureTextEntry={true}
              placeholder="Enter your password"
              placeholderTextColor="#90A4AE"
            />
          </View>
          
          <View style={styles.inputWrapper}>
            <Text style={styles.inputLabel}>Role</Text>
            <TextInput
              style={[styles.input, styles.disabledInput]}
              value={state?.user.role}
              editable={false}
              placeholder="Your role"
              placeholderTextColor="#90A4AE"
            />
          </View>
          
          <TouchableOpacity 
            style={styles.updateButton} 
            onPress={handleUpdate}
            activeOpacity={0.8}
          >
            <Text style={styles.updateButtonText}>
              {loading ? "Please Wait..." : "Update Profile"}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      
      <View style={styles.footerContainer}>
        <FooterMenu />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  headerContainer: {
    alignItems: "center",
    marginTop: 40,
    marginBottom: 20,
  },
  imageContainer: {
    marginBottom: 15,
  },
  profileImage: {
    height: 120,
    width: 120,
    borderRadius: 60,
    borderWidth: 3,
    borderColor: "#4DB6AC",
  },
  titleText: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#212121",
  },
  formContainer: {
    paddingHorizontal: 25,
  },
  warningText: {
    color: "#F44336",
    fontSize: 13,
    textAlign: "center",
    marginBottom: 20,
  },
  inputWrapper: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: "500",
    color: "#424242",
    marginBottom: 8,
    paddingLeft: 4,
  },
  input: {
    backgroundColor: "#E0F2F1",
    height: 50,
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    color: "#424242",
  },
  disabledInput: {
    backgroundColor: "#ECEFF1",
    color: "#78909C",
  },
  updateButton: {
    backgroundColor: "#4DB6AC",
    height: 50,
    borderRadius: 8,
    marginTop: 10,
    marginBottom: 30,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  updateButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
  footerContainer: {
    justifyContent: "flex-end",
  },
});

export default Account;